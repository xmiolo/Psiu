package br.com.psiu.conversationsApi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConversationsApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConversationsApiApplication.class, args);
	}

}
